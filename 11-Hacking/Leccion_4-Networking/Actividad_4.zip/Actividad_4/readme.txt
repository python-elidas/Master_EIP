Descripción de la imagen:
    Izquierda script con ataque Man In The Middle ejecutado.
    Derecha arriba trafico captado en el puerto 443.
    Derecha abajo, verificación de la ip del equipo atacante.

Conclusión: 
    Si bien es cierto que una vez ejecutado el ataque, la conexión a internet se interrumpe en la victima
    en la propio imagen se ve que el ataque se esta lanzando de forma satisfactoria. Queda pendiente crear
    una herramienta basándose en este código para poder implementar este tipo de ataques con otros módulos.