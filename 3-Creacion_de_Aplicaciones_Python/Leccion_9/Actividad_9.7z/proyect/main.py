'''
Author: Oscar Gutierrez
Email: o.guty66@gmail.com
Date: 2021-04-28
'''
# __LIBRARIES__ #
from fastapi import FastAPI, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import json
import csv
import os
import io


# __MAIN CODE__ #
# creamosla aplicacion llamada app
app = FastAPI()

# Guardamos la ruta del proyecto
MEDIA_ROOT = os.path.expanduser('~/virtual_envs/FastAPI/proyect/iris.csv')


# creamos la URL con su metodo GET y la funcion asociada
@app.get('/irisGet')
async def root():
    # Cargamos el dataset
    X_df = pd.read_csv(MEDIA_ROOT)
    # Lo transformamos a json:
    data = X_df.to_json(orient="index")
    data = json.loads(data)
    # Retornar el dataset
    return data


# Creamos el modelo de datos
class Iris(BaseModel):
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float
    species: str


# creamos la URL con su metodo POST y la funcion asociada
@app.post("/irisPost/")
async def irisPost(item: Iris):
    # Leemos el archivo iris.csv
    with open(MEDIA_ROOT, 'a', newline='') as csvfile:
        # idenntificamos los campos
        fieldnames = [
            'sepal_length', 'sepal_width',
            'petal_length', 'petal_width',
            'species'
        ]
        # escribimos sobre el csv
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        # insertar en la última fila:
        writer.writerow({
            'sepal_length': item.sepal_length,
            'sepal_width': item.sepal_width,
            'petal_length': item.petal_length,
            'petal_width': item.petal_width,
            'species': item.species
        })
    return item


# creamos la URL con su metodo PUT y la funcion asociada
@app.put("/irisPut/{item_id}")
async def irisPut(item_id: int, item: Iris):
    # Leemos el csv
    df = pd.read_csv(MEDIA_ROOT)
    # Modificamos el último dato con los valores que nos lleguen:
    df.loc[df.index[item_id], 'sepal_length'] = item.sepal_length
    df.loc[df.index[item_id], 'sepal_width'] = item.sepal_width,
    df.loc[df.index[item_id], 'petal_length'] = item.petal_length,
    df.loc[df.index[item_id], 'petal_width'] = item.petal_width,
    df.loc[df.index[item_id], 'species'] = item.species
    # convertir a csv
    df.to_csv(MEDIA_ROOT, index=False)
    # Retornamos el id que hemos modificado y el dato en formato diccionario:
    return {"item_id": item_id, **item.dict()}


# creamos la URL con su metodo DELETE y la funcion asociada
@app.delete("/irisDelete/{item_id}")
async def deleteData(item_id: int):
    # Leemos el csv con ayuda de pandas:
    df = pd.read_csv(MEDIA_ROOT)
    # Eliminar la última fila
    df.drop(df.index[item_id], inplace=True)
    # convertir a csv
    df.to_csv(MEDIA_ROOT, index=False)
    return 'Eliminado'


# creamos la URL con su metodo GET y la funcion asociada
@app.get('/irisGraph/')
async def irisGraph():
    # leemos el data frame
    df = pd.read_csv('2_IrisSpecies.csv')
    # quitamos la primera columna
    df = df.drop('Id', axis=1)
    plot = sns.FacetGrid(df, hue='Species', height=5.2)\
        .map(plt.scatter, 'PetalLengthCm', 'PetalWidthCm')\
        .add_legend()
    plot.fig.suptitle('Especies en función del Pétalo')
    output = io.BytesIO()
    # convertimos el grafico en un png
    plot.savefig(output, format='png')
    return Response(content=output.getvalue(), media_type='image/png')

# __NOTES__ #
'''

'''
# __BIBLIOGRAPHY__ #
'''

'''
