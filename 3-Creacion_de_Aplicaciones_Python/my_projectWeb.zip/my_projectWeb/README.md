Primeros pasos:
# Aquí pondremos las instrucciones para poder ejecutar nuestra aplicación
# TODO: Instrucción crear Entorno virtual
# TODO: Instrucción entrar Entorno virtual
# TODO: Instrucción desactivar Entorno virtual
# TODO: Instrucción eliminar Entorno virtual
# TODO: Instrucción crear archivo requirements.txt
# TODO: Instrucción para ejecutar la aplicación
# TODO: Instrucciones para migrar la base de datos.
# TODO: Instrucción crear un superusuario
# TODO: Instrucción para crear archivo de traducción
# TODO: Instrucción compilar la traducción
# TODO: Instrucción para eliminar el Entorno Virtual
