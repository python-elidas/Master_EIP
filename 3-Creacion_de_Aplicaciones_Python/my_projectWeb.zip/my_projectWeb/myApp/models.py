from django.db import models

# Create your models here.
# TODO: crear el modelo de datos
